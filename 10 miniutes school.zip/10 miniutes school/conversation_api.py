import os
import pickle
import numpy as np
from fastapi import FastAPI, Request
from pydantic import BaseModel
from sentence_transformers import SentenceTransformer
from collections import deque
import faiss
import google.generativeai as genai

# Load Google API Key from environment or set manually
GOOGLE_API_KEY = os.getenv("GOOGLE_API_KEY")
if not GOOGLE_API_KEY:
    raise EnvironmentError("Google API key not found. Set 'GOOGLE_API_KEY' in your environment.")

genai.configure(api_key=GOOGLE_API_KEY)
GEMINI_MODEL = genai.GenerativeModel("gemini-1.5-flash-latest")

# Config
EMBEDDING_MODEL = "distiluse-base-multilingual-cased-v1"
FAISS_INDEX_PATH = "vector_store/faiss_index.bin"
CHUNKS_PATH = "vector_store/chunks.pkl"
TOP_K = 3
chat_memory = deque(maxlen=5)

# Load embeddings
print(" Loading model and index...")
model = SentenceTransformer(EMBEDDING_MODEL)
index = faiss.read_index(FAISS_INDEX_PATH)
with open(CHUNKS_PATH, "rb") as f:
    chunks = pickle.load(f)

# FastAPI app
app = FastAPI(title="Simple RAG Conversation API")

# Request body model
class QueryRequest(BaseModel):
    query: str

# Helper functions
def embed_query(query: str) -> np.ndarray:
    return model.encode([query])

def retrieve_chunks(query: str) -> list:
    query_vec = embed_query(query)
    distances, indices = index.search(np.array(query_vec), TOP_K)
    return [chunks[i] for i in indices[0]]

def build_prompt(query: str, retrieved_chunks: list) -> str:
    memory_context = "\n".join(f"Q: {q}\nA: {a}" for q, a in chat_memory)
    context_str = ''.join(f'- {chunk.strip()}\n' for chunk in retrieved_chunks)
    prompt = f"""Use the following memory and context to answer the question in Bangla or English.

Short-term memory:
{memory_context}

Retrieved document context:
{context_str}

Question: {query}

Answer:"""
    return prompt

# API Endpoint
@app.post("/ask")
async def ask_question(payload: QueryRequest):
    query = payload.query
    retrieved = retrieve_chunks(query)
    prompt = build_prompt(query, retrieved)

    try:
        response = GEMINI_MODEL.generate_content(prompt)
        answer = response.text.strip()
    except Exception as e:
        answer = f" Error generating answer: {e}"

    chat_memory.append((query, answer))
    return {"query": query, "answer": answer}
